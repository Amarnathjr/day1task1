
class Stack {
  constructor() {
    this.items = []; 
  }
  push(element){
   
     this.items.push(element);

  }
  pop(){
    if(this.empty()){
        return "stack is empty";
    }
     return this.items.pop();
  }
  peek(){
    if(this.empty()){
        return "stack is empty";
    }
    return this.items[this.items.length-1];
  }
  empty(){
    
    return this.items.length===0;
  }
  print(){
    console.log(this.items.join("  "));
  }

}
var stack=new Stack();
stack.push(10);
stack.push(50);
stack.push(50);
stack.push(50);

stack.push(50);
stack.push(20);
stack.pop();
stack.peek();
stack.empty();
console.log(stack.peek());
stack.print();


